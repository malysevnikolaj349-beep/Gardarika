"""HTTP API routes for Gardarika admin interface.

This module defines the aiohttp route handlers for the admin API.
Handlers are responsible for validating incoming data, performing
authorization checks, invoking the appropriate service methods and
returning JSON responses.  Only a subset of routes is implemented
here for demonstration purposes.
"""

from __future__ import annotations

from typing import Any

from aiohttp import web
from pydantic import ValidationError

from app.schemas.requests import PlayerUpdateRequest
from app.services.players import PlayerService


def _require_auth(request: web.Request) -> None:
    """Ensure that the request includes a valid admin token.

    The token can be provided either via the ``X-Admin-Token`` header or
    as the ``token`` query parameter.  The expected token value is
    configured on the application as ``request.app['admin_token']``.

    Raises:
        web.HTTPUnauthorized: if the token is missing or incorrect.
    """
    expected = request.app.get("admin_token")
    provided = (
        request.headers.get("X-Admin-Token")
        or request.rel_url.query.get("token")
    )
    if not expected or provided != expected:
        raise web.HTTPUnauthorized(
            text="{\"detail\": \"Invalid or missing admin token\"}",
            content_type="application/json",
        )


async def update_player(request: web.Request) -> web.Response:
    """Handle PUT /api/players/{player_id} for updating a player.

    Parses the incoming JSON body into a ``PlayerUpdateRequest``,
    delegates to ``PlayerService.update_player`` and returns a
    JSON response indicating success or failure.  Invalid payloads
    result in a 400 Bad Request with a JSON error message.  If the
    player does not exist, a 404 Not Found is returned.
    """
    _require_auth(request)
    player_id_str = request.match_info.get("player_id")
    try:
        player_id = int(player_id_str)
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(
            text="{\"detail\": \"Invalid player id\"}",
            content_type="application/json",
        )
    try:
        payload = PlayerUpdateRequest(**await request.json())
    except ValidationError as exc:
        # Return validation errors as JSON
        return web.json_response(
            status=400,
            data={"detail": "Invalid request", "errors": exc.errors()},
        )
    # Obtain services from application context
    player_service: PlayerService = request.app["player_service"]
    updated = await player_service.update_player(
        player_id, **payload.model_dump(exclude_none=True)
    )
    if not updated:
        raise web.HTTPNotFound(
            text="{\"detail\": \"Player not found or no fields to update\"}",
            content_type="application/json",
        )
    return web.json_response({"status": "ok", "player_id": player_id})


def setup_routes(app: web.Application) -> None:
    """Register all API routes on the application."""
    app.router.add_route("PUT", "/api/players/{player_id}", update_player)