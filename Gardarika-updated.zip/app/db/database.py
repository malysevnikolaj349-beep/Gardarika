"""Database helper for Gardarika.

This module provides a simple wrapper around `aiosqlite` that
automatically manages the underlying connection lifecycle.  It can be
used as an asynchronous context manager so that connections are opened
and closed automatically when entering and exiting the context.  A
single shared connection instance is maintained for the lifetime of
the application.

Example:

    async with Database("./db.sqlite3") as db:
        # run queries via db.connection
        rows = await db.connection.execute("SELECT 1").fetchall()
"""

from __future__ import annotations

import aiosqlite


class Database:
    """Asynchronous SQLite database wrapper.

    A thin wrapper around `aiosqlite` that opens a single connection
    on demand.  When used as a context manager, the connection is
    automatically created on entry and closed on exit.  Attempting to
    access the connection before it has been initialised raises a
    RuntimeError.
    """

    def __init__(self, path: str) -> None:
        #: Filesystem path to the SQLite database
        self.path = path
        #: Underlying aiosqlite connection.  This is set after
        #: ``connect`` is called and cleared on ``close``.
        self._connection: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        """Open a connection to the SQLite database.

        This method should be called once during application startup.  It
        configures row_factory to return rows as dict-like objects.
        """
        if self._connection is None:
            self._connection = await aiosqlite.connect(self.path)
            # return rows as aiosqlite.Row which behaves like a mapping
            self._connection.row_factory = aiosqlite.Row

    async def close(self) -> None:
        """Close the underlying database connection.

        If no connection has been established, this method is a no-op.
        """
        if self._connection is not None:
            await self._connection.close()
            self._connection = None

    async def __aenter__(self) -> "Database":
        """Async context manager entry.  Ensures the connection is open."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        """Async context manager exit.  Closes the connection."""
        await self.close()

    @property
    def connection(self) -> aiosqlite.Connection:
        """Return the underlying database connection.

        Raises:
            RuntimeError: if called before ``connect``.
        """
        if self._connection is None:
            raise RuntimeError(
                "Database connection has not been initialised. Did you call connect()?"
            )
        return self._connection