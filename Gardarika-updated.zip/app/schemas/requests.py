"""Request schemas for Gardarika API.

This module defines Pydantic models for validating incoming API requests.
Using strongly typed request models helps ensure that the backend
receives correctly formatted data and provides meaningful error
messages back to the client when the payload is invalid.
"""

from pydantic import BaseModel, Field


class PlayerUpdateRequest(BaseModel):
    """
    Schema for updating a player's profile via the admin API.

    All fields are optional; when a field is omitted, the existing value
    for that field will be preserved. Validators ensure that integer
    fields are non‑negative (or at least 1 for the level), while boolean
    fields allow explicit True/False or None values.
    """

    level: int | None = Field(
        default=None,
        ge=1,
        description="New level for the player (must be >=1)",
    )
    gold: int | None = Field(
        default=None,
        ge=0,
        description="New gold amount for the player (must be >=0)",
    )
    experience: int | None = Field(
        default=None,
        ge=0,
        description="New experience points for the player (must be >=0)",
    )
    is_pk: bool | None = Field(
        default=None,
        description="Whether the player is flagged as PK (Player Killer)",
    )
    is_vip: bool | None = Field(
        default=None,
        description="Whether the player has VIP status",
    )
    in_jail: bool | None = Field(
        default=None,
        description="Whether the player is currently in jail",
    )
