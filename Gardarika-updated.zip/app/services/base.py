"""Base service classes for data access.

Services in Gardarika encapsulate business logic and database access
for specific domains such as players, economy, world state, etc.  To
avoid duplication of common patterns when working with the SQLite
database, this module defines a base class with helper methods for
executing queries.
"""

from __future__ import annotations

from typing import Any, Iterable

from app.db.database import Database


class BaseService:
    """Base class for all services interacting with the database."""

    def __init__(self, db: Database) -> None:
        #: Shared database instance
        self.db = db

    async def _execute(
        self,
        query: str,
        params: Iterable[Any] | None = None,
        *,
        fetch: bool = False,
        fetch_one: bool = False,
    ) -> Any:
        """Execute a SQL query against the database.

        This helper automatically commits transactions for non-select
        queries.  For SELECT queries it optionally returns all rows or
        a single row based on the ``fetch`` and ``fetch_one`` flags.

        Args:
            query: SQL statement to execute.  Can be any valid SQL.
            params: Sequence of positional parameters to bind.  If
                omitted, no parameters are bound.
            fetch: If True, return all resulting rows.  Only
                meaningful for SELECT statements.
            fetch_one: If True, return only the first row.  Only
                meaningful for SELECT statements.

        Returns:
            Either None for non-select queries, a list of rows for
            ``fetch=True`` or a single row for ``fetch_one=True``.
        """
        params = tuple(params or ())
        # Determine if this is a SELECT query by looking at the first
        # keyword.  SQLite is case-insensitive for keywords.
        is_select = query.lstrip().lower().startswith("select")
        # Use the connection directly; ensure it has been initialised
        conn = self.db.connection
        async with conn.execute(query, params) as cursor:
            if is_select:
                if fetch_one:
                    row = await cursor.fetchone()
                    return row
                if fetch:
                    rows = await cursor.fetchall()
                    return rows
                # Default: do not fetch results
                return None
            # For non-select queries we need to commit after execution
            await conn.commit()
            return None