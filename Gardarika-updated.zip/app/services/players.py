"""Service for managing player data in Gardarika.

This module defines ``PlayerService`` which provides high-level
operations for reading and updating player records stored in the
database.  It utilises the common functionality from
``app.services.base.BaseService`` to execute queries and return
results.  The service is intentionally minimal for demonstration
purposes and can be expanded to include additional business logic as
needed.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from app.services.base import BaseService


class PlayerService(BaseService):
    """Service for CRUD operations on players."""

    async def update_player(self, player_id: int, **fields: Any) -> bool:
        """Update a player's fields.

        Only non-None values in ``fields`` will be included in the SQL
        ``UPDATE`` statement.  If no values are provided, the method
        short-circuits and does nothing.  Returns ``True`` if at least
        one record was updated, ``False`` otherwise.

        Args:
            player_id: Identifier of the player to update.
            **fields: Column values to update.  Keys must correspond
                to column names in the ``players`` table.

        Returns:
            bool: True if a row was updated; False if no matching
                player exists or ``fields`` is empty.
        """
        # Filter out None values; only update provided fields
        update_data: dict[str, Any] = {
            key: value for key, value in fields.items() if value is not None
        }
        if not update_data:
            return False
        # Build SET clause and parameter list
        set_clauses = [f"{col} = ?" for col in update_data.keys()]
        params = list(update_data.values())
        params.append(player_id)
        sql = f"UPDATE players SET {', '.join(set_clauses)} WHERE id = ?"
        await self._execute(sql, params)
        # Check how many rows were affected
        conn = self.db.connection
        # aiosqlite doesn't provide rowcount on execute, so run a SELECT to verify
        row = await self._execute(
            "SELECT 1 FROM players WHERE id = ?", (player_id,), fetch_one=True
        )
        return row is not None