"""Entry point for running the Gardarika admin API.

This module defines a factory for creating the aiohttp application
instance, wiring together the database, services and routes.  When run
as a script it launches the server with reasonable defaults.
"""

from __future__ import annotations

import asyncio
import logging
from aiohttp import web

from app.db.database import Database
from app.services.players import PlayerService
from app.web.routes import setup_routes


def create_app() -> web.Application:
    """Create and configure the aiohttp application."""
    app = web.Application()
    # Configure logging with basic setup; applications can modify
    # this configuration as needed.
    logging.basicConfig(level=logging.INFO)
    # Load configuration from environment variables or defaults.  In
    # real projects you'd read a config file or use pydantic settings.
    import os

    db_path = os.environ.get("DB_PATH", "./db.sqlite3")
    admin_token = os.environ.get("ADMIN_TOKEN", "secret")
    # Initialise database and services
    db = Database(db_path)
    # Connect immediately; in a full project you might connect on
    # startup signal instead
    # We'll use asyncio.create_task to run connect so as not to block
    async def on_startup(app: web.Application) -> None:
        await db.connect()
        app["player_service"] = PlayerService(db)
        app["admin_token"] = admin_token

    async def on_cleanup(app: web.Application) -> None:
        await db.close()

    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    # Register routes
    setup_routes(app)
    return app


if __name__ == "__main__":
    app = create_app()
    # Use asyncio.run to start the web app
    web.run_app(app, host="0.0.0.0", port=8080)