"""Logging configuration for Gardarika.

This module exposes a helper function to set up rotating file
handlers for both the API server and Telegram bot.  Using rotating
files helps prevent log files from growing indefinitely.  Applications
can call ``configure_logging`` during startup to install handlers.
"""

import logging
from logging.handlers import RotatingFileHandler
from typing import Optional


def configure_logging(
    *,
    api_log_path: str = "./logs/api.log",
    bot_log_path: str = "./logs/bot.log",
    max_bytes: int = 1_000_000,
    backup_count: int = 3,
    level: int = logging.INFO,
) -> None:
    """Configure logging with separate rotating file handlers.

    Args:
        api_log_path: Path for API log file.
        bot_log_path: Path for bot log file.
        max_bytes: Maximum size of a log file before rotation.
        backup_count: Number of backup files to keep.
        level: Default log level for the root logger.
    """
    # Create log directory if missing
    import os

    os.makedirs(os.path.dirname(api_log_path), exist_ok=True)
    os.makedirs(os.path.dirname(bot_log_path), exist_ok=True)
    # Create formatters and handlers
    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    api_handler = RotatingFileHandler(
        api_log_path, maxBytes=max_bytes, backupCount=backup_count
    )
    api_handler.setFormatter(formatter)
    bot_handler = RotatingFileHandler(
        bot_log_path, maxBytes=max_bytes, backupCount=backup_count
    )
    bot_handler.setFormatter(formatter)
    # Configure root logger and named loggers
    logging.basicConfig(level=level, handlers=[api_handler])
    # The bot logger can be obtained via logging.getLogger("bot")
    bot_logger = logging.getLogger("bot")
    bot_logger.setLevel(level)
    bot_logger.addHandler(bot_handler)